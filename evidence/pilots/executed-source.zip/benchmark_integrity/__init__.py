"""A small, auditable evaluation of unauthorized benchmark modification."""

__version__ = "0.2.1"
